//
//  ViewController.swift
//  QuizGame
//
//  Created by Derrick Woodall on 6/26/25.
//
/*
Things we need
 -Menu screen
 -Game screen
 -Answer object
 -Question object
  */


import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func startGame() {
        let vc = storyboard?.instantiateViewController(withIdentifier: "game") as! GameViewController
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
        
        /*
         @IBAction func startGame() {
             let vc = storyboard?.instantiateViewController(withIdentifier: "game") as! GameViewController
             vc.modalPresentationStyle = .fullScreen
             present(vc, animated: true)         */
    }
    
}
